# RPostgres and RPostgreSQL

# TRY RPostgres here
install.packages("RPostgres")


library(RPostgres)
library(DBI)

pw <- {
  "87654321"
}

con <- dbConnect(RPostgres::Postgres(),
                 host = 'localhost',
                 port = 5432,
                 dbname = 'omop_cdm',
                 user = 'postgres',
                 password = pw)


dbListTables(con)


# basic queries

dbGetQuery(con, 'SELECT * FROM person')

# find all type 2 diabetes patients without CVD


diabetes_condition <- "SELECT person.person_id
                  FROM person, condition_occurrence, concept
                  WHERE person.person_id = condition_occurrence.person_id
                  AND condition_occurrence.condition_concept_id = concept.concept_id
                  AND concept.concept_name = 'E119'"


dbGetQuery(con, diabetes_condition)

diabetes_drug <- "SELECT person.person_id
                  FROM person, drug_exposure, concept
                  WHERE person.person_id = drug_exposure.person_id
                  AND drug_exposure.drug_concept_id = concept.concept_id
                  AND concept.concept_name = '20030800060'"
# need to edit drug code

dbGetQuery(con, diabetes_drug)



